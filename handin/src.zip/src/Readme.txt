Handin by Fredrik Holsten and Tobias Ludwig

How to run:
python stereoRec2.py
To run single images, keep runAll = False
To run with hyper-parameter selection, set runAll =True


Requirements:
cv2
numpy
skimage
matplotlib
You need a data folder and a result folder. See the paths in the code.

